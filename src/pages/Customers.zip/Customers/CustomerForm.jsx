import { useMemo } from "react";
import { useForm } from "react-hook-form";

import FormGrid from "../../components/form/FormGrid";
import InputField from "../../components/form/form-input/InputField";
import SelectField from "../../components/form/form-input/SelectField";
import TextAreaField from "../../components/form/form-input/TextAreaField";

import { useAreas } from "../../queries/useArea";
import { useDeliveryLocations } from "../../queries/useDeliveryLocation";

export default function CustomerForm({

  defaultValues,

  onSubmit,

  isLoading,

  onCancel,

  isEdit = false

}) {

  const {

    control,

    register,

    handleSubmit,

    watch,

    formState: { errors }

  } = useForm({

    defaultValues

  });

  const { data: areaData } =
    useAreas();

  const { data: deliveryLocationData } =
    useDeliveryLocations();

  const areas =
    areaData?.data ??
    areaData ??
    [];

  const deliveryLocations =
    deliveryLocationData?.data ??
    deliveryLocationData ??
    [];

  const selectedAreaId =
    watch("areaId");

  const areaOptions =
    useMemo(() =>

      areas.map(x => ({

        id: x.id,

        name: `${x.areaCode} - ${x.areaName}`

      })),

      [areas]

    );

  const deliveryLocationOptions =
    useMemo(() =>

      deliveryLocations

        .filter(x =>

          !selectedAreaId ||

          x.areaId === Number(selectedAreaId)

        )

        .map(x => ({

          id: x.id,

          name: x.locationName

        })),

      [

        deliveryLocations,

        selectedAreaId

      ]

    );

  return (

    <form

      onSubmit={handleSubmit(onSubmit)}

      className="space-y-6"

    >

      <FormGrid

        cols={2}

        gap={5}

      >

        <InputField

          name="customerCode"

          control={control}

          label="Customer Code"

          placeholder="Enter Customer Code"

          required

        />

        <InputField

          name="customerName"

          control={control}

          label="Customer Name"

          placeholder="Enter Customer Name"

          required

        />

        <InputField

          name="mobileNo"

          control={control}

          label="Mobile Number"

          placeholder="Enter Mobile Number"

          required

        />

        <InputField

          name="alternateMobileNo"

          control={control}

          label="Alternate Mobile"

          placeholder="Enter Alternate Mobile"

        />

        <InputField

          name="email"

          control={control}

          label="Email"

          placeholder="Enter Email"

        />

        <SelectField

          name="areaId"

          control={control}

          label="Area"

          options={areaOptions}

          placeholder="Select Area"

          required

          error={errors.areaId}

        />

        <SelectField

          name="deliveryLocationId"

          control={control}

          label="Delivery Location"

          options={deliveryLocationOptions}

          placeholder="Select Delivery Location"

          error={errors.deliveryLocationId}

        />

        <InputField

          name="houseDoorNo"

          control={control}

          label="House / Door No"

          placeholder="Enter House / Door No"

          required

        />

        <InputField

          name="landmark"

          control={control}

          label="Landmark"

          placeholder="Enter Landmark"

        />

        {

          isEdit && (

            <div>

              <label className="block text-sm font-medium mb-2">

                Status

              </label>

              <select

                {...register("isActive")}

                className="w-full border rounded-xl px-4 py-2.5"

              >

                <option value={true}>

                  Active

                </option>

                <option value={false}>

                  Inactive

                </option>

              </select>

            </div>

          )

        }

      </FormGrid>

      <TextAreaField

        name="remarks"

        control={control}

        label="Remarks"

        placeholder="Enter Remarks"

        rows={3}

      />

      <TextAreaField

        name="deliveryNotes"

        control={control}

        label="Delivery Notes"

        placeholder="Enter Delivery Notes"

        rows={3}

      />

      <div className="flex justify-end gap-3 pt-4 border-t">

        <button

          type="button"

          onClick={onCancel}

          className="px-5 py-2.5 border rounded-xl"

        >

          Cancel

        </button>

        <button

          type="submit"

          disabled={isLoading}

          className="px-5 py-2.5 bg-blue-600 text-white rounded-xl"

        >

          {

            isLoading

              ? "Saving..."

              : "Save"

          }

        </button>

      </div>

    </form>

  );

}